from flask import Flask
from flask import render_template
from os import listdir
import json
from os.path import isfile, join
from flask import Flask, request
app = Flask(__name__, template_folder='static/templates')


@app.route('/', methods=['GET', 'POST'])
def hello():
    if request.method == 'GET':
        return render_template('index.html')
    else:
        keywords = request.form['keywords']
        kn = request.form['kn']
        photo = request.files['photo']
        photo.save(photo.filename)
        return ''


@app.route('/results')
def results():
    mypath = "static/images"
    onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    return json.dumps(onlyfiles)


if __name__ == '__main__':
    app.run(debug=True)
